#HW7 Roman Numeral Converter

## Compile
```Bash
javac RomanNumeralConverter.java
java RomanNumeralConverter
```

## Run
Input numbers or roman numerals (not excedding 3999)  
Example:
	input:  
		9  
		IX  
		476  
		CDLXXVI  
		
	output:  
		IX  
		9  
		CDLXXVI  
		476  

##Error detection
1. Invalid number  
2. Invalid roman numeral  
